package EvalutionJdbcSql;

public class Databasedetails {
	 public static final String DATABASE_DRIVER="com.mysql.cj.jdbc.Driver";
	    public static final String DATABASE_URL="jdbc:mysql://localhost:3306/User_Registration";
	    public static final String DATABASE_USER="root";
	    public static final String DATABASE_PASS="12345";


}
