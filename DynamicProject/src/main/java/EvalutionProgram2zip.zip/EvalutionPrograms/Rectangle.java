package EvalutionPrograms;

public class Rectangle implements Shape{
	
	public void area()
	{
		System.out.println("The Rectangle class method is invoked");
	}

}
