package EvalutionPrograms;

public class FactoryMethod {
	
	public Shape getInstance(String str)
	{
		if (str.equals("open"))
			return new Traingle();
		else if (str.equals("close"))
			return new Rectangle();
		else
			return new Square();
	}

}
