package EvalutionPrograms;

public class Traingle implements Shape{
	
	public void area() {
		System.out.println("Area of the Traiangle is invoked");
	}

}
