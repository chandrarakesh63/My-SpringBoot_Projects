package EvalutionPrograms;

public class Square implements Shape{
	
	public void area()
	{
		System.out.println("This is the square class method");
	}

}
