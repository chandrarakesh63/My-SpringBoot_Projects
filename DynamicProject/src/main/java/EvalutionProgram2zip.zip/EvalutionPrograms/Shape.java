package EvalutionPrograms;

public interface Shape {
	
	void area();

}
